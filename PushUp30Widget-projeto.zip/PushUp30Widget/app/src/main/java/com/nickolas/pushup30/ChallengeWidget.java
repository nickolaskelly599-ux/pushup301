package com.nickolas.pushup30;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class ChallengeWidget extends AppWidgetProvider {
    static final String PREF = "pushup30";
    static final String ACTION_DONE = "com.nickolas.pushup30.DONE";
    static final String ACTION_RESET = "com.nickolas.pushup30.RESET";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    static void update(Context context, AppWidgetManager manager, int id) {
        int completed = context.getSharedPreferences(PREF, 0).getInt("completed", 0);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_challenge);
        views.setTextViewText(R.id.progress, completed + "/30 dias concluídos");
        views.setProgressBar(R.id.bar, 30, completed, false);
        views.setTextViewText(R.id.next, nextText(completed));
        Intent done = new Intent(context, WidgetActionReceiver.class).setAction(ACTION_DONE);
        Intent reset = new Intent(context, WidgetActionReceiver.class).setAction(ACTION_RESET);
        views.setOnClickPendingIntent(R.id.done, PendingIntent.getBroadcast(context, 1, done,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        views.setOnClickPendingIntent(R.id.reset, PendingIntent.getBroadcast(context, 2, reset,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        manager.updateAppWidget(id, views);
    }

    static String nextText(int completed) {
        int day = completed + 1;
        if (day > 30) return "Desafio concluído! 💯";
        if (day >= 29) return "Dia " + day + ": recuperação";
        int week = (day - 1) / 7 + 1;
        int reps = week == 1 ? 30 : week == 2 ? 40 : week == 3 ? 50 : 60;
        boolean session = day == 1 || day == 3 || day == 5 || day == 8 || day == 10 ||
                day == 12 || day == 15 || day == 17 || day == 19 || day == 22 ||
                day == 24 || day == 26;
        return session ? "Dia " + day + " • sessão: " + reps + " flexões" :
                "Dia " + day + " • recuperação/descanso";
    }

    static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, ChallengeWidget.class);
        int[] ids = manager.getAppWidgetIds(name);
        for (int id : ids) update(context, manager, id);
    }
}
