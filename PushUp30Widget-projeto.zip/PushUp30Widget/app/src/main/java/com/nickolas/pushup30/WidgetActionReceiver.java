package com.nickolas.pushup30;

import android.app.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class WidgetActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(ChallengeWidget.PREF, 0);
        if (ChallengeWidget.ACTION_DONE.equals(intent.getAction())) {
            int value = prefs.getInt("completed", 0);
            if (value < 30) {
                prefs.edit().putInt("completed", value + 1).apply();
                Toast.makeText(context, "Dia " + (value + 1) + " concluído!", Toast.LENGTH_SHORT).show();
            }
        } else if (ChallengeWidget.ACTION_RESET.equals(intent.getAction())) {
            prefs.edit().putInt("completed", 0).apply();
            Toast.makeText(context, "Progresso reiniciado", Toast.LENGTH_SHORT).show();
        }
        ChallengeWidget.refreshAll(context);
    }
}
